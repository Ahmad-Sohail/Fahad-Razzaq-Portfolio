# Executive Portfolio — Fahad Razzaq

A premium, bespoke single-page portfolio website for **Fahad Razzaq**, an Administration Specialist with 14+ years of leadership in Operations, Supply Chain, and Procurement across Pakistan, Saudi Arabia, and the UAE. Designed for corporate recruiters and executive clients, featuring an interactive Three.js 3D Career Globe, executive CV viewer, and contact inquiry portal.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural and UX decisions were confirmed during Phase 1 clarification:

- **3D Feature Integration**: An **Interactive 3D Career Globe** connecting Fahad's international career hubs (Lahore, Pakistan; Sharma / NEOM, Saudi Arabia; and Dubai, UAE) with procedural 3D arcs, coordinates, PBR earth sphere, and site inspection cards.
- **Profile Presentation**: An **Executive Portrait Illustration with Custom Photo Upload Support**, framed in a polished gold border ring, allowing instant client/recruiter test uploads or reset to the executive presentation.
- **Corporate Recruiter Tool**: An **Interactive Executive CV Viewer & Print Modal** formatted for corporate hiring committees with print-optimized CSS, structured KPI summaries, and export capabilities.

---

### 1. Overview & Core Concept

- **What It Does**: Presents Fahad Razzaq's 14+ years of cross-border administrative leadership in an elegant, responsive, and interactive digital portfolio.
- **Target Audience**: Corporate clients, construction and engineering project directors, multinational HR executives, and Gulf/Pakistan recruiters seeking senior administration, camp management, and procurement leaders.
- **Key Value**: Instantly validates scale of responsibility (300+ workforce, 4 mega project sites including NEOM City, multi-country logistics, regulatory compliance) through verified timeline milestones, interactive 3D geographic footprints, and corporate credentials.

---

### 2. User Experience & Visual Design

#### Key User Flows
1. **Hero & First Impression**: Executive header with smooth navigation, high-contrast serif typography ("Fahad Razzaq"), value proposition, direct CTAs ("View Experience" & "Contact Me"), live statistics ribbon, and executive portrait with instant photo upload capability.
2. **Interactive 3D Career Globe**: Interactive Three.js globe highlighting Fahad's journey between Lahore, NEOM, and Dubai. Users can rotate, zoom, click site pins, view project specs, and collapse controls into a minimal bottom dock.
3. **Executive Biography & Strategic Pillars**: 2-column narrative covering operational transformation, supply chain optimization, and digital tools, paired with 3 key pillars (Leadership, Strategic Planning, Cross-Cultural Management).
4. **Career Timeline (14+ Years)**: Vertical timeline with navy track, gold nodes, and comprehensive bullet points detailing NEOM camp management (300+ staff), CASA REINA site oversight, Dubai trading operations, and Afzal Electronics multi-outlet expansion.
5. **Core Skills Grid**: 10 categorized competencies (Leadership, Project Management, Procurement, Fleet, Budget, etc.) with contextual depth and practical application tags.
6. **Education, Certifications & Languages**: Dual-column display detailing academic degree (B.Com, Punjab University), technical diploma, health & safety credentials (IOSA, OSHA), and bilingual proficiency (English, Urdu).
7. **Contact Portal & Recruiter Action**: Direct contact channels (Phone, Email, LinkedIn, Location), interactive inquiry form with validation and success feedback, and a printable executive resume modal.

#### Visual Identity & Theme
- **Primary Navy Blue**: `#0B1F3A` (dominant branding, text contrast, dark structural cards, footer)
- **Warm Gold Accent**: `#C9A227` (accent lines, button highlights, pin nodes, badge rings)
- **Off-White Canvas**: `#F7F5F0` (warm executive paper canvas, 60% dominant neutral)
- **Crisp White Surfaces**: `#FFFFFF` (elevated cards, modals, clean content frames)
- **Muted Slate/Charcoal**: `#4A5568` & `#1A202C` (high-readability body copy, secondary metadata)

#### Typography Pairing
- **Display Headings**: *Playfair Display* (Google Fonts, serif, weights 600 & 700) — authoritative, timeless, corporate prestige.
- **Body & Controls**: *Inter* (Google Fonts, sans-serif, weights 400, 500, 600) — optimal digital readability and clean form rendering.
- **Tabular Figures**: `tabular-nums` for all metrics, stats, and date ranges.

#### Interactive Feedback & Motion
- Smooth anchor scrolling with sticky blur-free navbar elevation.
- Micro-interactions on buttons, timeline entries, and skills cards ($\le 150\text{ms}$ cubic transitions).
- Zero-jank Three.js render loop with pointer damping and software-WebGL safety.

---

### 3. Key Product Decisions & Trade-Offs

- **Three.js Career Globe vs Static Map**:
  - *Chosen Approach*: Interactive procedural 3D sphere with Three.js r160+, latitude/longitude coordinate projection, great-circle bezier curves between Lahore, Sharma/NEOM, and Dubai, and pulse-free gold markers.
  - *Why*: Conveys multi-national cross-border capability in a high-impact visual that immediately differentiates Fahad from generic resumes.
  - *Safety Guard*: Software WebGL detection (`isSoftwareGl`), requestRender pacing, and zero-404 procedural canvas textures for landmass/grid lines.
- **Printable CV Modal**:
  - *Chosen Approach*: Integrated modal featuring an ATS-friendly, clean corporate one-page resume view with a `window.print()` trigger and CSS `@media print` rules.
  - *Why*: Recruiters and hiring managers often need a tangible 1-click printable summary to circulate in internal committee meetings.
- **Photo Upload & Executive Avatar**:
  - *Chosen Approach*: Default executive portrait illustration with an interactive "Upload Custom Photo" button that loads via HTML5 FileReader (with instant reset option).
  - *Why*: Corporate clients or Fahad himself can preview the exact headshot they prefer while maintaining an immaculate default appearance.

---

### 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                             Executive App Shell                             │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │ [Navbar] Brand Wordmark · Links (About/Exp/Skills/Edu/Contact) · CV   │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│  ┌─────────────────────────────────┐   ┌─────────────────────────────────┐  │
│  │ [Hero Section]                  │   │ [Interactive 3D Career Globe]   │  │
│  │ Name, Executive Title, Value    │   │ Three.js Canvas: Pakistan,      │  │
│  │ Metrics Ribbon (14+ Yrs, 300+)  │   │ Saudi Arabia & UAE Arcs         │  │
│  │ Photo Frame + Upload Action     │   │ Collapsible Viewport Controls   │  │
│  └─────────────────────────────────┘   └─────────────────────────────────┘  │
│                                                                             │
│  ┌─────────────────────────────────┐   ┌─────────────────────────────────┐  │
│  │ [About Section]                 │   │ [Experience Timeline]           │  │
│  │ Executive Narrative             │   │ 4 Detailed Roles: NEOM, CASA    │  │
│  │ 3 Strategic Pillars             │   │ REINA, Al-Qadesia, Afzal Group  │  │
│  └─────────────────────────────────┘   └─────────────────────────────────┘  │
│                                                                             │
│  ┌─────────────────────────────────┐   ┌─────────────────────────────────┐  │
│  │ [Skills Matrix]                 │   │ [Education & Certifications]    │  │
│  │ 10 Core Administrative Domains  │   │ B.Com, Mechanical, OSHA, IOSA   │  │
│  └─────────────────────────────────┘   └─────────────────────────────────┘  │
│                                                                             │
│  ┌─────────────────────────────────┐   ┌─────────────────────────────────┐  │
│  │ [Contact Portal]                │   │ [Executive Resume Modal]        │  │
│  │ Direct Coordinates & Form       │   │ Print-Ready Corporate CV        │  │
│  └─────────────────────────────────┘   └─────────────────────────────────┘  │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │ [Footer] Copyright · LinkedIn Quick Link · Clean Executive Seal       │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### State & Component Breakdown
- **Navigation & Active Section**: Sticky header tracking current scroll position.
- **Career Globe State**: Active selected country/hub (Pakistan, Saudi Arabia, UAE), rotation speed toggle, and collapsible controls dock.
- **Executive Photo State**: Local state with FileReader preview and default SVG corporate avatar.
- **Resume Modal State**: Full-screen printable modal state with toggle open/close.
- **Contact Form State**: Form input validation, submission status, and feedback toast.
