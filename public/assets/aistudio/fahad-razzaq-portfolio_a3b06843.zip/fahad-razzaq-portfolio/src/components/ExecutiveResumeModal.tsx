import React, { useEffect } from 'react';
import { PERSONAL_INFO, EXPERIENCES, SKILLS, EDUCATION, CERTIFICATIONS, LANGUAGES } from '../data/portfolioData';

interface ExecutiveResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExecutiveResumeModal: React.FC<ExecutiveResumeModalProps> = ({ isOpen, onClose }) => {
  // Handle ESC key to close modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex justify-center p-4 sm:p-6 lg:p-10 animate-in fade-in duration-200">
      {/* Modal Dialog Card */}
      <div className="relative bg-surface w-full max-w-4xl rounded-3xl shadow-2xl border border-border overflow-hidden my-auto">
        {/* Modal Action Bar (Hidden in Print) */}
        <div className="no-print bg-background/90 text-foreground px-6 py-4 flex items-center justify-between border-b border-border sticky top-0 z-10 backdrop-blur-md">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-gold" />
            <span className="text-xs font-semibold tracking-wider uppercase text-gold">
              Executive Curriculum Vitae
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="rounded-full bg-gold px-4 py-2 text-xs font-semibold text-background hover:bg-glow transition-all cursor-pointer flex items-center gap-2 shadow-sm"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
              </svg>
              <span>Print / Save PDF</span>
            </button>

            <button
              onClick={onClose}
              className="flex h-8 w-8 items-center justify-center rounded-full border border-border text-muted-foreground hover:text-foreground hover:bg-surface transition-colors cursor-pointer"
              aria-label="Close CV Modal"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* Printable Resume Document Body */}
        <div className="p-8 sm:p-12 text-foreground bg-surface space-y-8 font-sans print:bg-white print:text-black">
          {/* Header */}
          <div className="border-b border-border pb-6 print:border-black">
            <h1 className="text-3xl sm:text-4xl font-display font-bold text-foreground print:text-black tracking-tight mb-1">
              {PERSONAL_INFO.name}
            </h1>
            <p className="text-sm sm:text-base font-semibold text-gold print:text-gray-800 mb-3">
              {PERSONAL_INFO.title}
            </p>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground print:text-gray-600">
              <span>{PERSONAL_INFO.location}</span>
              <span aria-hidden="true">·</span>
              <span>{PERSONAL_INFO.phone}</span>
              <span aria-hidden="true">·</span>
              <span>{PERSONAL_INFO.email}</span>
              <span aria-hidden="true">·</span>
              <a
                href={PERSONAL_INFO.linkedin}
                target="_blank"
                rel="noreferrer"
                className="text-gold print:text-black underline underline-offset-2"
              >
                {PERSONAL_INFO.linkedinDisplay}
              </a>
            </div>
          </div>

          {/* Executive Summary */}
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-gold print:text-black border-b border-border print:border-black pb-1 mb-2">
              Executive Summary
            </h2>
            <p className="text-xs leading-relaxed text-muted-foreground print:text-gray-800">
              {PERSONAL_INFO.summaryParagraph1}
            </p>
          </div>

          {/* Professional Experience */}
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-gold print:text-black border-b border-border print:border-black pb-1 mb-4">
              Professional Experience
            </h2>
            <div className="space-y-6">
              {EXPERIENCES.map((exp) => (
                <div key={exp.id} className="space-y-1.5">
                  <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
                    <div>
                      <span className="text-sm font-bold text-foreground print:text-black">{exp.role}</span>
                      <span className="text-xs text-muted-foreground print:text-gray-600 font-medium ml-1.5">
                        — {exp.company} ({exp.location})
                      </span>
                    </div>
                    <span className="text-xs font-semibold text-muted-foreground print:text-gray-600 tabular-nums">
                      {exp.period}
                    </span>
                  </div>
                  {exp.project && (
                    <div className="text-xs text-gold print:text-gray-800 font-semibold">
                      Project: {exp.project}
                    </div>
                  )}
                  <ul className="list-disc list-outside pl-4 space-y-1 text-xs text-muted-foreground print:text-gray-700 leading-normal">
                    {exp.bullets.map((bullet, idx) => (
                      <li key={idx}>{bullet}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          {/* Core Competencies Matrix */}
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-gold print:text-black border-b border-border print:border-black pb-1 mb-3">
              Core Competencies & Capabilities
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs text-muted-foreground print:text-gray-700">
              {SKILLS.map((skill) => (
                <div key={skill.id} className="flex items-center gap-1.5">
                  <span className="w-1 h-1 rounded-full bg-gold print:bg-black" />
                  <span className="font-medium">{skill.name}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Education & Credentials Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-gold print:text-black border-b border-border print:border-black pb-1 mb-2">
                Education
              </h2>
              <div className="space-y-2 text-xs">
                {EDUCATION.map((edu) => (
                  <div key={edu.degree}>
                    <div className="font-bold text-foreground print:text-black">{edu.degree}</div>
                    <div className="text-muted-foreground print:text-gray-600">{edu.institution} ({edu.period})</div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-gold print:text-black border-b border-border print:border-black pb-1 mb-2">
                Certifications & Languages
              </h2>
              <div className="space-y-2 text-xs">
                {CERTIFICATIONS.map((cert) => (
                  <div key={cert.title}>
                    <div className="font-bold text-foreground print:text-black">{cert.title}</div>
                    <div className="text-muted-foreground print:text-gray-600">{cert.issuer} · {cert.date}</div>
                  </div>
                ))}
                <div className="pt-1 text-xs text-muted-foreground print:text-gray-700">
                  <span className="font-semibold text-foreground print:text-black">Languages: </span>
                  {LANGUAGES.map((l) => `${l.language} (${l.level})`).join(' · ')}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
