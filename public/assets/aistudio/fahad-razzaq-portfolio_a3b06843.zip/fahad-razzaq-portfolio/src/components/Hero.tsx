import React, { useState, useRef } from 'react';
import { PERSONAL_INFO } from '../data/portfolioData';
import bannerPic from "../../public/assets/aistudio/hero.jpg";

interface HeroProps {
  onOpenResumeModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenResumeModal }) => {
  const [customPhoto, setCustomPhoto] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setCustomPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <section id="top" className="relative flex min-h-svh flex-col overflow-hidden">
      {/* Background Hero Image */}
      <img
        src={bannerPic}
        alt="Construction mega-project site at dusk"
        className="absolute inset-0 h-full w-full object-cover"
        width={1920}
        height={1080}
      />
      {/* Gradients */}
      <div className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-background/30" />
      <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-background to-transparent" />

      {/* Hero Content Container */}
      <div className="relative mx-auto flex w-full max-w-6xl flex-1 flex-col justify-center px-4 pt-28 pb-10 sm:px-6 sm:pt-32 sm:pb-16">
        <p className="flex items-center gap-2.5 sm:gap-3 text-[11px] sm:text-sm font-semibold uppercase tracking-[0.25em] sm:tracking-[0.35em] text-gold">
          <span className="h-px w-8 sm:w-12 bg-gold/60" />
          Administration Specialist
        </p>

        <div className="mt-4 sm:mt-6 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8 lg:gap-10">
          <div className="max-w-2xl">
            <h1 className="font-display text-[clamp(2.75rem,12vw,6rem)] font-bold leading-[1.05] text-foreground">
              Fahad<span className="block italic text-gold">Razzaq</span>
            </h1>

            <p className="mt-4 sm:mt-6 max-w-xl text-sm sm:text-base lg:text-lg leading-relaxed text-muted-foreground">
              14+ years driving administrative excellence across{' '}
              <span className="font-semibold text-foreground">Pakistan</span>,{' '}
              <span className="font-semibold text-foreground">Saudi Arabia</span> &amp; the{' '}
              <span className="font-semibold text-foreground">UAE</span> — leading workforces, procurement and operations on major project sites.
            </p>

            {/* CTAs */}
            <div className="mt-7 flex flex-col items-stretch gap-3 sm:mt-9 sm:flex-row sm:flex-wrap sm:items-center sm:gap-4">
              <a
                href="#experience"
                className="group inline-flex items-center justify-center gap-2 rounded-full bg-gold px-5 py-3 sm:px-7 sm:py-3.5 text-xs sm:text-sm font-semibold text-background transition-all hover:bg-glow shadow-lg shadow-gold/10 whitespace-nowrap cursor-pointer"
              >
                <span>View Experience</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-arrow-right h-4 w-4 transition-transform group-hover:translate-x-1"
                  aria-hidden="true"
                >
                  <path d="M5 12h14" />
                  <path d="m12 5 7 7-7 7" />
                </svg>
              </a>

              <a
                href="#contact"
                className="inline-flex items-center justify-center gap-2 rounded-full border border-foreground/25 px-5 py-3 sm:px-7 sm:py-3.5 text-xs sm:text-sm font-semibold text-foreground backdrop-blur-sm transition-colors hover:border-gold hover:text-gold whitespace-nowrap cursor-pointer"
              >
                Contact Me
              </a>

              <button
                onClick={onOpenResumeModal}
                className="inline-flex items-center justify-center gap-2 rounded-full border border-gold/40 bg-gold/10 px-4 py-3 sm:px-6 sm:py-3.5 text-xs sm:text-sm font-semibold text-gold transition-colors hover:bg-gold hover:text-background cursor-pointer whitespace-nowrap"
              >
                Executive CV
              </button>
            </div>
          </div>

        </div>

        {/* Stat strip */}
        <div className="mt-12 sm:mt-16 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-border bg-border sm:grid-cols-4">
          {PERSONAL_INFO.stats.map((stat) => (
            <div key={stat.label} className="bg-background/60 px-3 py-4 sm:px-5 sm:py-6 backdrop-blur-md">
              <p className="font-display text-2xl sm:text-3xl font-bold text-gold tabular-nums">
                {stat.value}
              </p>
              <p className="mt-1 text-[10px] sm:text-xs font-medium uppercase tracking-wider text-muted-foreground">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Bouncing Scroll Down Button */}
      <a
        href="#about"
        aria-label="Scroll to about section"
        className="absolute right-6 bottom-8 hidden h-12 w-12 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:border-gold hover:text-gold lg:flex cursor-pointer"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-arrow-down h-5 w-5 animate-bounce"
          aria-hidden="true"
        >
          <path d="M12 5v14" />
          <path d="m19 12-7 7-7-7" />
        </svg>
      </a>
    </section>
  );
};
