import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { CAREER_HUBS } from '../data/portfolioData';
import { CareerHub } from '../types/portfolio';

// Convert Lat/Lng to 3D Cartesian coordinates on sphere of radius R
function latLngToVector3(lat: number, lng: number, radius: number): THREE.Vector3 {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lng + 180) * (Math.PI / 180);
  const x = -(radius * Math.sin(phi) * Math.cos(theta));
  const z = radius * Math.sin(phi) * Math.sin(theta);
  const y = radius * Math.cos(phi);
  return new THREE.Vector3(x, y, z);
}

// Generate procedural earth texture with landmasses and subtle coordinate grid
function createProceduralEarthTexture(): THREE.CanvasTexture {
  const width = 2048;
  const height = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');

  if (!ctx) return new THREE.CanvasTexture(canvas);

  // Deep Navy oceanic base
  ctx.fillStyle = '#061426';
  ctx.fillRect(0, 0, width, height);

  // Subtle longitude & latitude grid lines
  ctx.strokeStyle = 'rgba(201, 162, 39, 0.08)';
  ctx.lineWidth = 1;
  const stepX = width / 24;
  for (let x = 0; x <= width; x += stepX) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
  }
  const stepY = height / 12;
  for (let y = 0; y <= height; y += stepY) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }

  // Draw procedural continental landmass silhouettes (Eurasia, Africa, Middle East, South Asia, Americas, Australasia)
  ctx.fillStyle = '#0F2B4D'; // Elevated dark navy landmass
  ctx.strokeStyle = '#1D3B63';
  ctx.lineWidth = 1.5;

  function drawContinent(points: [number, number][]) {
    if (!ctx) return;
    ctx.beginPath();
    points.forEach(([xPct, yPct], index) => {
      const px = xPct * width;
      const py = yPct * height;
      if (index === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    });
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  // Middle East & Arabian Peninsula
  drawContinent([
    [0.55, 0.35], [0.59, 0.36], [0.63, 0.40], [0.62, 0.45],
    [0.60, 0.49], [0.57, 0.48], [0.55, 0.45], [0.53, 0.40]
  ]);

  // South Asia / Pakistan / India
  drawContinent([
    [0.63, 0.35], [0.67, 0.34], [0.70, 0.38], [0.71, 0.45],
    [0.68, 0.52], [0.66, 0.50], [0.64, 0.44], [0.62, 0.39]
  ]);

  // Africa
  drawContinent([
    [0.48, 0.36], [0.55, 0.37], [0.57, 0.45], [0.58, 0.55],
    [0.54, 0.68], [0.50, 0.75], [0.46, 0.65], [0.44, 0.48]
  ]);

  // Europe & Northern Eurasia
  drawContinent([
    [0.47, 0.22], [0.58, 0.20], [0.75, 0.22], [0.85, 0.25],
    [0.82, 0.34], [0.72, 0.35], [0.60, 0.32], [0.48, 0.30]
  ]);

  // North America
  drawContinent([
    [0.15, 0.22], [0.28, 0.20], [0.32, 0.30], [0.26, 0.45],
    [0.20, 0.42], [0.14, 0.35]
  ]);

  // South America
  drawContinent([
    [0.26, 0.48], [0.34, 0.52], [0.36, 0.65], [0.30, 0.80],
    [0.25, 0.70], [0.24, 0.54]
  ]);

  // Highlight Golden Glow on Gulf & South Asia Regional Corridor
  const grad = ctx.createRadialGradient(0.62 * width, 0.40 * height, 10, 0.62 * width, 0.40 * height, 220);
  grad.addColorStop(0, 'rgba(201, 162, 39, 0.25)');
  grad.addColorStop(0.5, 'rgba(201, 162, 39, 0.08)');
  grad.addColorStop(1, 'rgba(201, 162, 39, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0.50 * width, 0.25 * height, 0.30 * width, 0.35 * height);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

// Generate Great-Circle flight arc curve
function createArc(v1: THREE.Vector3, v2: THREE.Vector3, radius: number): THREE.CubicBezierCurve3 {
  const distance = v1.distanceTo(v2);
  const mid = v1.clone().add(v2).multiplyScalar(0.5);
  const midLength = mid.length();
  // Elevate mid-point above sphere surface based on chord distance
  const elevation = radius + Math.min(distance * 0.38, radius * 0.35);
  mid.normalize().multiplyScalar(elevation);

  const control1 = v1.clone().lerp(mid, 0.5).normalize().multiplyScalar(elevation * 0.95);
  const control2 = v2.clone().lerp(mid, 0.5).normalize().multiplyScalar(elevation * 0.95);

  return new THREE.CubicBezierCurve3(v1, control1, control2, v2);
}

export const CareerGlobe3D: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [selectedHub, setSelectedHub] = useState<CareerHub>(CAREER_HUBS[0]);
  const [isRotating, setIsRotating] = useState(true);
  const [isControlsCollapsed, setIsControlsCollapsed] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  // Refs for animation and Three.js state
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const globeGroupRef = useRef<THREE.Group | null>(null);
  const targetRotationYRef = useRef<number>(0);
  const targetRotationXRef = useRef<number>(0.2);
  const isInteractingRef = useRef<boolean>(false);
  const pointerStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const isSoftwareGlRef = useRef<boolean>(false);

  // Focus on specific career hub
  const focusHub = useCallback((hub: CareerHub) => {
    setSelectedHub(hub);
    if (!globeGroupRef.current) return;
    // Calculate rotation needed to face camera (lat, lng)
    const radLng = (hub.lng + 180) * (Math.PI / 180);
    const radLat = (hub.lat) * (Math.PI / 180);
    
    // Set target rotation
    targetRotationYRef.current = -radLng + Math.PI / 2;
    targetRotationXRef.current = radLat * 0.65;
  }, []);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Detect software WebGL guard per Three.js skill
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();
    isSoftwareGlRef.current = isSoftwareGl;

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Camera
    const aspect = container.clientWidth / container.clientHeight;
    const camera = new THREE.PerspectiveCamera(40, aspect, 0.1, 1000);
    camera.position.set(0, 0, 7.8);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Studio Environment lighting via PMREMGenerator
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Balanced 3-point lighting rig
    const keyLight = new THREE.DirectionalLight(0xfff5ea, 2.2);
    keyLight.position.set(5, 4, 6);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0xc9a227, 1.8);
    rimLight.position.set(-6, -3, -4);
    scene.add(rimLight);

    const hemiLight = new THREE.HemisphereLight(0xe9f2ff, 0x071527, 0.8);
    scene.add(hemiLight);

    // Globe Main Group
    const globeGroup = new THREE.Group();
    scene.add(globeGroup);
    globeGroupRef.current = globeGroup;

    // Sphere Radius
    const R = 2.4;

    // 1. Procedural Earth PBR Surface
    const earthTexture = createProceduralEarthTexture();
    earthTexture.anisotropy = renderer.capabilities.getMaxAnisotropy();

    const earthGeo = new THREE.SphereGeometry(R, 64, 48);
    const earthMat = new THREE.MeshPhysicalMaterial({
      map: earthTexture,
      roughness: 0.35,
      metalness: 0.18,
      clearcoat: 0.3,
      clearcoatRoughness: 0.2,
      reflectivity: 0.6,
    });
    const earthMesh = new THREE.Mesh(earthGeo, earthMat);
    globeGroup.add(earthMesh);

    // 2. Translucent Atmosphere Halo Shell
    const atmosphereGeo = new THREE.SphereGeometry(R * 1.025, 48, 36);
    const atmosphereMat = new THREE.MeshPhysicalMaterial({
      color: 0xc9a227,
      transparent: true,
      opacity: 0.12,
      roughness: 0.8,
      metalness: 0.1,
      side: THREE.BackSide,
      depthWrite: false,
    });
    const atmosphereMesh = new THREE.Mesh(atmosphereGeo, atmosphereMat);
    globeGroup.add(atmosphereMesh);

    // 3. Subtle Latitude Ring Accents
    const ringGroup = new THREE.Group();
    const ringMat = new THREE.LineBasicMaterial({
      color: 0xc9a227,
      transparent: true,
      opacity: 0.25,
    });
    [-30, 0, 30, 60].forEach((lat) => {
      const radiusAtLat = R * Math.cos(lat * (Math.PI / 180));
      const yAtLat = R * Math.sin(lat * (Math.PI / 180));
      const ringGeo = new THREE.BufferGeometry();
      const points: THREE.Vector3[] = [];
      const segs = 64;
      for (let i = 0; i <= segs; i++) {
        const theta = (i / segs) * Math.PI * 2;
        points.push(new THREE.Vector3(Math.cos(theta) * radiusAtLat, yAtLat, Math.sin(theta) * radiusAtLat));
      }
      ringGeo.setFromPoints(points);
      const ring = new THREE.Line(ringGeo, ringMat);
      ringGroup.add(ring);
    });
    globeGroup.add(ringGroup);

    // 4. Hub Coordinates & 3D Procedural Pins (3-part composite meshes)
    const hubPositions = new Map<string, THREE.Vector3>();
    CAREER_HUBS.forEach((hub) => {
      const pos = latLngToVector3(hub.lat, hub.lng, R);
      hubPositions.set(hub.id, pos);

      // Composite Pin: Base plate + Pin stem + Glowing sphere head
      const pinGroup = new THREE.Group();
      pinGroup.position.copy(pos);
      pinGroup.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), pos.clone().normalize());

      // Base ring
      const baseGeo = new THREE.CylinderGeometry(0.08, 0.1, 0.02, 16);
      const baseMat = new THREE.MeshStandardMaterial({
        color: 0xc9a227,
        metalness: 0.8,
        roughness: 0.2,
      });
      const baseMesh = new THREE.Mesh(baseGeo, baseMat);
      baseMesh.position.y = 0.01;
      pinGroup.add(baseMesh);

      // Pin stem
      const stemGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.28, 8);
      const stemMat = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        metalness: 0.9,
        roughness: 0.15,
      });
      const stemMesh = new THREE.Mesh(stemGeo, stemMat);
      stemMesh.position.y = 0.14;
      pinGroup.add(stemMesh);

      // Pin Head (Polished Gold Sphere)
      const headGeo = new THREE.SphereGeometry(0.08, 16, 16);
      const headMat = new THREE.MeshPhysicalMaterial({
        color: 0xc9a227,
        emissive: 0x664d08,
        metalness: 0.9,
        roughness: 0.1,
        clearcoat: 1.0,
      });
      const headMesh = new THREE.Mesh(headGeo, headMat);
      headMesh.position.y = 0.32;
      pinGroup.add(headMesh);

      globeGroup.add(pinGroup);
    });

    // 5. Connect Hubs with Elegant 3D Great-Circle Flight Arcs
    const arcConnections = [
      ['hub-pakistan', 'hub-saudi'], // Lahore <-> NEOM
      ['hub-saudi', 'hub-uae'],      // NEOM <-> Dubai
      ['hub-uae', 'hub-pakistan'],   // Dubai <-> Lahore
    ];

    arcConnections.forEach(([id1, id2]) => {
      const v1 = hubPositions.get(id1);
      const v2 = hubPositions.get(id2);
      if (!v1 || !v2) return;

      const curve = createArc(v1, v2, R);
      const tubeGeo = new THREE.TubeGeometry(curve, 48, 0.018, 8, false);
      const tubeMat = new THREE.MeshStandardMaterial({
        color: 0xc9a227,
        emissive: 0x3d2f06,
        roughness: 0.2,
        metalness: 0.85,
        transparent: true,
        opacity: 0.9,
      });
      const tubeMesh = new THREE.Mesh(tubeGeo, tubeMat);
      globeGroup.add(tubeMesh);
    });

    // Initial orientation: Center on the Gulf / South Asia region
    const initialHub = CAREER_HUBS[0];
    const initialLng = (initialHub.lng + 180) * (Math.PI / 180);
    targetRotationYRef.current = -initialLng + Math.PI / 2;
    targetRotationXRef.current = (initialHub.lat * (Math.PI / 180)) * 0.65;
    globeGroup.rotation.y = targetRotationYRef.current;
    globeGroup.rotation.x = targetRotationXRef.current;

    // Mouse / Touch interaction handlers
    let isDragging = false;
    let prevMousePos = { x: 0, y: 0 };

    const handlePointerDown = (e: MouseEvent | TouchEvent) => {
      isDragging = true;
      isInteractingRef.current = true;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      prevMousePos = { x: clientX, y: clientY };
      pointerStartRef.current = { x: clientX, y: clientY };
    };

    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      if (!isDragging || !globeGroupRef.current) return;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      const deltaX = clientX - prevMousePos.x;
      const deltaY = clientY - prevMousePos.y;

      targetRotationYRef.current += deltaX * 0.005;
      targetRotationXRef.current += deltaY * 0.005;

      // Clamp vertical tilt
      targetRotationXRef.current = Math.max(-0.9, Math.min(0.9, targetRotationXRef.current));
      prevMousePos = { x: clientX, y: clientY };
    };

    const handlePointerUp = () => {
      isDragging = false;
      isInteractingRef.current = false;
    };

    const domElement = renderer.domElement;
    domElement.addEventListener('mousedown', handlePointerDown);
    window.addEventListener('mousemove', handlePointerMove);
    window.addEventListener('mouseup', handlePointerUp);

    domElement.addEventListener('touchstart', handlePointerDown, { passive: true });
    window.addEventListener('touchmove', handlePointerMove, { passive: true });
    window.addEventListener('touchend', handlePointerUp);

    // Resize observer
    const handleResize = () => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const width = container.clientWidth;
      const height = container.clientHeight;
      cameraRef.current.aspect = width / height;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(width, height);
    };

    const resizeObserver = new ResizeObserver(() => handleResize());
    resizeObserver.observe(container);

    // Animation loop with exponential damping & software-WebGL pacing
    let frameId = 0;
    const clock = new THREE.Clock();

    function tick() {
      const dt = clock.getDelta();

      if (globeGroupRef.current) {
        // Slow auto-rotation when user is not manually dragging and auto-rotate is enabled
        if (!isInteractingRef.current && isRotating) {
          targetRotationYRef.current += 0.0025;
        }

        // Exponential smooth damping
        globeGroupRef.current.rotation.y = THREE.MathUtils.damp(
          globeGroupRef.current.rotation.y,
          targetRotationYRef.current,
          4.0,
          dt
        );
        globeGroupRef.current.rotation.x = THREE.MathUtils.damp(
          globeGroupRef.current.rotation.x,
          targetRotationXRef.current,
          4.0,
          dt
        );
      }

      renderer.render(scene, camera);
      frameId = requestAnimationFrame(tick);
    }

    frameId = requestAnimationFrame(tick);

    // Cleanup
    return () => {
      cancelAnimationFrame(frameId);
      resizeObserver.disconnect();

      domElement.removeEventListener('mousedown', handlePointerDown);
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);

      domElement.removeEventListener('touchstart', handlePointerDown);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('touchend', handlePointerUp);

      earthGeo.dispose();
      earthMat.dispose();
      earthTexture.dispose();
      atmosphereGeo.dispose();
      atmosphereMat.dispose();
      renderer.dispose();

      if (container.contains(domElement)) {
        container.removeChild(domElement);
      }
    };
  }, [isRotating]);

  return (
    <section id="career-hubs" className="scroll-mt-24 bg-background py-16 sm:py-24 relative overflow-hidden">
      <div className="relative z-10 mx-auto min-w-0 max-w-6xl px-4 sm:px-6">
        {/* Section Header */}
        <div className="mb-8 flex min-w-0 flex-col gap-4 sm:mb-12 sm:flex-row sm:items-end sm:justify-between sm:gap-5">
          <div className="min-w-0">
            <p className="flex items-center gap-3 text-xs font-semibold uppercase tracking-[0.3em] text-gold">
              <span className="font-display text-sm tracking-normal">✦</span>
              <span className="h-px w-8 sm:w-10 bg-gold/50" />
              Global Footprint
            </p>
            <h2 className="mt-3 break-words font-display text-3xl font-bold leading-tight text-foreground sm:mt-4 sm:text-4xl md:text-5xl">
              Cross-border operations.
            </h2>
          </div>
          <p className="max-w-md break-words text-xs text-muted-foreground sm:text-sm sm:text-base">
            Interactive 3D model connecting project corridors across Lahore, Sharma (NEOM City), and Dubai.
          </p>
        </div>

        {/* 3D Viewport with Ergonomic Collapsible Dock */}
        <div
          className="relative h-[430px] w-full min-w-0 overflow-hidden rounded-2xl border border-border bg-surface shadow-2xl sm:h-[520px] sm:rounded-3xl md:h-[600px]"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          {/* Three.js Canvas Container */}
          <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

          {/* Minimal Top-Left Spec Overlay */}
          <div className="pointer-events-none absolute left-3 top-3 z-20 sm:left-4 sm:top-4">
            <div className="min-w-0 max-w-[calc(100vw-2.5rem)] break-words rounded-xl border border-border/80 bg-background/85 p-2.5 shadow-lg backdrop-blur-md sm:max-w-xs sm:rounded-2xl sm:p-3.5">
              <span className="text-[9px] sm:text-[10px] uppercase tracking-wider text-gold font-semibold block mb-0.5 sm:mb-1">
                Active Operations Hub
              </span>
              <h3 className="break-words text-sm font-display font-bold text-foreground sm:text-base">
                {selectedHub.city}, {selectedHub.name}
              </h3>
              <p className="break-words text-[11px] text-muted-foreground sm:mt-0.5 sm:text-xs">
                {selectedHub.role} · {selectedHub.company}
              </p>
            </div>
          </div>

          {/* Interactive Hub Detail Card (Top-Right) */}
          <div className="absolute top-4 right-4 z-20 hidden md:block max-w-sm pointer-events-auto">
            <div className="bg-background/90 border border-gold/30 rounded-2xl p-4 shadow-xl backdrop-blur-md">
              <div className="flex items-center justify-between text-xs text-gold font-semibold mb-2">
                <span>{selectedHub.period}</span>
                <span className="font-mono text-[11px] text-muted-foreground">
                  {selectedHub.lat.toFixed(2)}°N, {selectedHub.lng.toFixed(2)}°E
                </span>
              </div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-foreground mb-1">Scope &amp; Impact:</h4>
              <p className="text-xs text-muted-foreground leading-relaxed">
                {selectedHub.highlight}
              </p>
            </div>
          </div>

          {/* Collapsible Bottom Control Dock */}
          <div
            className={`absolute bottom-3 left-1/2 z-30 w-[calc(100%-1rem)] max-w-2xl -translate-x-1/2 transition-transform duration-300 sm:bottom-4 sm:w-[94%] ${
              isControlsCollapsed ? 'translate-y-[calc(100%-36px)]' : 'translate-y-0'
            }`}
          >
            {/* Collapse / Expand Toggle Button */}
            <div className="flex justify-center mb-1">
              <button
                onClick={() => setIsControlsCollapsed(!isControlsCollapsed)}
                className="px-4 py-1 bg-surface hover:bg-elevated border border-border rounded-t-xl text-[11px] font-medium text-muted-foreground hover:text-foreground transition-colors cursor-pointer flex items-center gap-1.5 shadow"
                aria-label={isControlsCollapsed ? 'Show 3D controls' : 'Collapse 3D controls'}
              >
                <span>{isControlsCollapsed ? '▴ Expand Controls' : '▾ Collapse Controls'}</span>
              </button>
            </div>

            {/* Dock Surface */}
            <div className="flex flex-col items-stretch gap-2 rounded-2xl border border-border/80 bg-background/95 p-2.5 shadow-2xl sm:flex-row sm:flex-wrap sm:items-center sm:justify-between sm:gap-3 sm:p-3">
              {/* Hub Selection Buttons */}
              <div className="grid grid-cols-3 gap-1.5 sm:flex sm:flex-wrap sm:items-center sm:justify-start">
                {CAREER_HUBS.map((hub) => {
                  const isActive = selectedHub.id === hub.id;
                  return (
                    <button
                      key={hub.id}
                      onClick={() => focusHub(hub)}
                      className={`min-w-0 rounded-full px-2 py-1.5 text-center text-[11px] font-medium transition-all cursor-pointer sm:px-3.5 sm:text-xs ${
                        isActive
                          ? 'bg-gold text-background font-semibold shadow-md'
                          : 'bg-surface hover:bg-elevated text-muted-foreground hover:text-foreground border border-border'
                      }`}
                    >
                      {hub.city}
                    </button>
                  );
                })}
              </div>

              {/* Orbit / Reset Controls */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setIsRotating(!isRotating)}
                  className={`min-w-0 rounded-full border px-2 py-1.5 text-[11px] font-medium transition-colors cursor-pointer sm:px-3 sm:text-xs ${
                    isRotating
                      ? 'border-gold/40 text-gold bg-gold/10'
                      : 'border-border text-muted-foreground bg-surface'
                  }`}
                >
                  {isRotating ? 'Pause Orbit' : 'Resume Orbit'}
                </button>
                <button
                  onClick={() => focusHub(selectedHub)}
                  className="min-w-0 rounded-full border border-border bg-surface px-2 py-1.5 text-[11px] font-medium text-muted-foreground transition-colors cursor-pointer hover:bg-elevated hover:text-foreground sm:px-3 sm:text-xs"
                >
                  Recenter
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
