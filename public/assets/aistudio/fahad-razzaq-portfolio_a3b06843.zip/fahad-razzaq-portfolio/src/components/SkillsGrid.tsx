import React, { useState } from 'react';
import { SKILLS } from '../data/portfolioData';

export const SkillsGrid: React.FC = () => {
  const [showDetailedGrid, setShowDetailedGrid] = useState(false);

  // 10 Core Skills from CV
  const skillNames = [
    'Leadership',
    'Critical Thinking',
    'Business Development',
    'Project Management',
    'Time Management',
    'Customer Services',
    'Fleet Management',
    'Procurement Management',
    'Budget Management',
    'Administrative Operations',
  ];

  // Repeat for smooth infinite marquee
  const row1Skills = [...skillNames, ...skillNames, ...skillNames];
  const row2Skills = [...skillNames.slice().reverse(), ...skillNames.slice().reverse(), ...skillNames.slice().reverse()];

  return (
    <section id="skills" className="scroll-mt-24 overflow-hidden bg-background py-16 sm:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="flex items-center gap-3 text-xs font-semibold uppercase tracking-[0.3em] text-gold">
              <span className="font-display text-sm tracking-normal">03</span>
              <span className="h-px w-10 bg-gold/50" />
              Expertise
            </p>
            <h2 className="mt-4 font-display text-4xl font-bold leading-tight text-foreground sm:text-5xl">
              Core skills.
            </h2>
          </div>

          <button
            onClick={() => setShowDetailedGrid(!showDetailedGrid)}
            className="self-start sm:self-auto rounded-full border border-border bg-surface px-4 py-2 text-xs font-medium text-muted-foreground transition-colors hover:border-gold/40 hover:text-foreground cursor-pointer flex items-center gap-2"
          >
            <span>{showDetailedGrid ? 'Hide Descriptions' : 'View Skill Details'}</span>
            <span className="text-gold">✦</span>
          </button>
        </div>

        {/* Detailed Grid if toggled */}
        {showDetailedGrid && (
          <div className="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 animate-in fade-in duration-300">
            {SKILLS.map((skill) => (
              <div
                key={skill.id}
                className="rounded-2xl border border-border bg-surface p-6 transition-all hover:border-gold/40"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-gold">
                    {skill.category}
                  </span>
                </div>
                <h3 className="font-display text-lg font-bold text-foreground mb-1.5">
                  {skill.name}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-3">
                  {skill.description}
                </p>
                <div className="flex flex-wrap gap-1.5 text-xs text-muted-foreground">
                  {skill.keywords.map((kw, i) => (
                    <span key={kw}>
                      {kw}{i < skill.keywords.length - 1 ? ' ·' : ''}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Dual Infinite Marquee Ribbons (Exact same as reference site) */}
      <div className="marquee-paused mt-14 space-y-5">
        {/* Row 1: Marquee Left (Clean pill with gold dot) */}
        <div className="flex w-max animate-marquee-left gap-5">
          {row1Skills.map((skill, idx) => (
            <span
              key={`r1-${idx}`}
              className="flex items-center gap-3 rounded-full border border-border bg-surface px-6 py-3.5 text-sm font-medium whitespace-nowrap text-foreground transition-colors hover:border-gold/50 cursor-default"
            >
              <span className="h-2 w-2 rounded-full bg-gold" />
              {skill}
            </span>
          ))}
        </div>

        {/* Row 2: Marquee Right (Gold tinted pill) */}
        <div className="flex w-max animate-marquee-right gap-5">
          {row2Skills.map((skill, idx) => (
            <span
              key={`r2-${idx}`}
              className="flex items-center gap-3 rounded-full bg-gold/10 px-6 py-3.5 text-sm font-medium whitespace-nowrap text-gold transition-colors hover:bg-gold hover:text-background cursor-default"
            >
              {skill}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
};
